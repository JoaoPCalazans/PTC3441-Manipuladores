% === Generate Data ===
function simple_graph_delp(v)
    % === Create Figure ===
    figure;
    data = squeeze(permute(v.Data, [3,1,2]));  % Now it's 701x3
    
    time = v.Time;
    plot(time, data(:,1), 'r', 'LineWidth', 1); hold on;
    plot(time, data(:,2), 'g', 'LineWidth',1);
    plot(time, data(:,3), 'b', 'LineWidth', 1);
    
    % === Formatting ===
    grid on;                         % Enable grid
    xlabel('Time (s)', 'FontSize', 12);     % X-axis label
    ylabel('Speed (º/s) ', 'FontSize', 12);    % Y-axis label
    title('RRR Joint speeds (degrees/s)', 'FontSize', 14);
    
    legend({'$\dot{\theta}_1$(t)', '$\dot{\theta}_2$(t)', '$\dot{\theta}_3$(t)'}, 'Location', 'best','Interpreter','latex');
    
    xlim([0 10]);        % Limit for x-axis
    %ylim([-1.5 1.5]);    % Limit for y-axis
end
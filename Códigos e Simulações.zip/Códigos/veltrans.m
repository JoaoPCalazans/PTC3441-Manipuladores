%% VELTRANS   
% Calcula o vetor de velocidades linear e angular de um sistema {B}, dado
% os valores em referência a um outro sistema {A}, parado em relação a {B},
% ou seja, com matriz de transformação constante, e idem informada.
% 
%% Calling Syntax
% vrelb=veltrans(vrela,brela)
%
%% I/O Variables
% |IN Double Array| *vrela*: _velocities vector relative to A_ Linear and angular velocities 6x1
% 
% |IN Double Matrix| *brela*: _B relative to A_  Homogeneous Transformation Matrix 4x4
% 
% |OU Double Matrix| *vrelb*: _velocities vector relative to B_ Linear and angular velocities 6x1
%
%% Example
% Conforme exercício 5.11 do Craig, 3a edição:
%
% vrela = [0; 2; -3; 1.41; 1.41; 0];
%
% brela = [0.86 -0.5 0 10; .5 .86 0 0; 0 0 1 5; 0 0 0 1];
%
% veltrans(vrela, brela);
%
%% Hypothesis
% RRR planar robot.
%
%% Limitations
% Os sistemas devem estar parados um em relação ao outro, com matrix de
% transformação constante.
% Os valores de todas as velocidades $\dot{x}, \dot{y}, \dot{z}$ e
% $\dot{\theta}_1, \dot{\theta}_2, \dot{\theta}_3$.
%
%% Version Control
%
% 1.0; Grupo 04; 2025/27/05 ; First issue.
%
%% Group Members
% * Guilherme Fortunato Miranda
%
%   13683786
%
% * João Pedro Dionizio Calazans
%
%   13673086
%    
%% Function
function vrelb=veltrans(vrela,brela)

%% Validity
% Not apply

%% Main Calculations
    oxis = [0 -brela(3,4) brela(2,4); brela(3,4) 0 -brela(1,4); -brela(2,4) brela(1,4) 0];
    rotation = brela(1:3,1:3)';
    arelbV = [rotation -rotation*oxis ; zeros(3,3) rotation];
    
%% Output Data
    vrelb = arelbV * vrela;
            
end
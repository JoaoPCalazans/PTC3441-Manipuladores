simul_thetas = out.thetas;

L= [0.5,0.3];
tRelw = [0.1 0.2 30];
bRels= [0,0,0];

figure;
hold on;

for i = 1:height(simul_thetas.Time)
    cla;  % clear axes before next frame (or update instead of replot)
    data = squeeze(permute(simul_thetas.Data, [3,1,2]));  % Now it's 701x3
    % Call your existing function with current joint angles
    plot_manipulator(data(i,1:3),L,tRelw,bRels);
    
    drawnow limitrate;
    %pause(0.001);  % optional: slow down for visible animation
end
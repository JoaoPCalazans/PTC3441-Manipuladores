% === Generate Data ===
function simple_graph_jac(v)
    % === Create Figure ===
    figure;
    data = v.data;  % Now it's 701x3
    time = v.Time;
    plot(time,data (:,1) , 'r', 'LineWidth', 1); hold on;
        
    % === Formatting ===
    grid on;                         % Enable grid
    xlabel('Time (s)', 'FontSize', 12);     % X-axis label
    ylabel('det(Jac) ', 'FontSize', 12);    % Y-axis label
    title('RRR Determinat of Jacobian', 'FontSize', 14);
    
    legend({'det(Jac)'}, 'Location', 'best','Interpreter','latex');
    
    %xlim([0 10]);        % Limit for x-axis
    %ylim([-1.5 1.5]);    % Limit for y-axis
end
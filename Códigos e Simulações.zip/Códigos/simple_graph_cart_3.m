% === Generate Data ===
function simple_graph_cart_3(v)
    % === Create Figure ===
    figure;
    data = squeeze(permute(v.Data, [3,1,2]));  % Now it's 701x3
    L =[0.5,0.3];
    %xytheta=zero
    for i = 1:size(data,1)
        T = kin(data(i,:), L);  % L stays the same
        xytheta(i,:) = itou(T);
        % Do something with result...
    end
    time = v.Time;
    %plot(xytheta(:,1),xytheta(:,2) , 'r', 'LineWidth', 1); hold on;
    %plot(time, , 'g', 'LineWidth',1);
    plot(time, xytheta(:,3), 'b', 'LineWidth', 1);
    
    % === Formatting ===
    grid on;                         % Enable grid
    xlabel('Time (s)', 'FontSize', 12);     % X-axis label
    ylabel('Orientation (º) ', 'FontSize', 12);    % Y-axis label
    title('RRR Orientation', 'FontSize', 14);
    
    legend({'Orientation(º)'}, 'Location', 'best','Interpreter','latex');
    
    %xlim([0 10]);        % Limit for x-axis
    %ylim([-1.5 1.5]);    % Limit for y-axis
end
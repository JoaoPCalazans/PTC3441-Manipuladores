%% CORIOLIS   
% Calcula a matriz $V(\Theta, \dot{\Theta})$ para determinação do vetor de forças
% dinâmicas $\tau$.
% Derivada das equações da dinâmica do movimento a partir da seção 6.7 do
% Craig.
%
%% Calling Syntax
% coriolis=coriolis(theta,dtheta)
%
%% I/O Variables
% |IN Double Array| *theta*: _Joint angles_  [ $\theta_1$ $\theta_2$ $\theta_3$] [degrees degrees degrees]
%
% |IN Double Array| *dtheta*: _Joint angular velocities_  [ $\dot{\theta_1}$ $\dot{\theta_2}$ $\dot{\theta_3}$] [degrees/seg degrees/seg degrees/seg]
%
% |OU Double Array| *coriolis*: $V(\Theta, \dot{\Theta})$ 3x3 Coriolis array
%
%% Example
% theta = [10 20 30];
%
% dtheta = [-30 30 10];
%
% coriolis=coriolis(theta,dtheta)
%
%% Hypothesis
% RRR planar robot.
%
%% Limitations
% A "Forma do usuário" é específica para o exercício de simulação e não tem
% validade para qualquer configuração de robô.
% Considera o robô planar com os valores de comprimentos dos ligamentos = {0.5, 0.3, 0}
% e Massas = {4.6, 2.3, 1} fixos.
%
%% Version Control
%
% 1.0; Grupo 04; 2025/31/05 ; First issue.
%
%% Group Members
% * Guilherme Fortunato Miranda
%
%   13683786
%
% * João Pedro Dionizio Calazans
%
%   13673086
%    
%% Function
function coriolis=coriolis(theta,dtheta)

%% Validity
% Not apply

%% Main Calculations
L = [0.5,0.3,0];
M = [4.6,2.3,1];
 
%% Output Data
    coriolis(1,:) =[- dtheta(2)*L(1)*(2*L(2)*M(2)*sin(theta(2)) + L(2)*M(3)*sin(theta(2)) + L(3)*M(3)*sin(theta(2) + theta(3))) - dtheta(3)*L(3)*M(3)*(L(1)*sin(theta(2) + theta(3)) + L(2)*sin(theta(3))), - dtheta(1)*L(1)*L(3)*M(3)*sin(theta(2) + theta(3)) - dtheta(2)*L(1)*L(3)*M(3)*sin(theta(2) + theta(3)) - dtheta(3)*L(1)*L(3)*M(3)*sin(theta(2) + theta(3)) - 2*dtheta(1)*L(1)*L(2)*M(2)*sin(theta(2)) - dtheta(1)*L(1)*L(2)*M(3)*sin(theta(2)) - 2*dtheta(2)*L(1)*L(2)*M(2)*sin(theta(2)) - dtheta(2)*L(1)*L(2)*M(3)*sin(theta(2)) - dtheta(3)*L(2)*L(3)*M(3)*sin(theta(3)), -L(3)*M(3)*(L(1)*sin(theta(2) + theta(3)) + L(2)*sin(theta(3)))*(dtheta(1) + dtheta(2) + dtheta(3))];
    coriolis(2,:) =[          dtheta(1)*L(1)*L(3)*M(3)*sin(theta(2) + theta(3)) + 2*dtheta(1)*L(1)*L(2)*M(2)*sin(theta(2)) + dtheta(1)*L(1)*L(2)*M(3)*sin(theta(2)) - dtheta(3)*L(2)*L(3)*M(3)*sin(theta(3)),                                                                                                                                                                                      -dtheta(3)*L(2)*L(3)*M(3)*sin(theta(3)),                     -L(2)*L(3)*M(3)*sin(theta(3))*(dtheta(1) + dtheta(2) + dtheta(3))];
    coriolis(3,:) =[                                             L(3)*M(3)*(dtheta(1)*L(2)*sin(theta(3)) + dtheta(2)*L(2)*sin(theta(3)) + dtheta(1)*L(1)*sin(theta(2) + theta(3))),                                                                                                                                                                               L(2)*L(3)*M(3)*sin(theta(3))*(dtheta(1) + dtheta(2)),                                                       0];

            
end
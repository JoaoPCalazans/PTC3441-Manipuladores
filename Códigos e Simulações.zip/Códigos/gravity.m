%% GRAVITY
% Calcula a matriz G($\Theta$) para determinação do vetor de forças
% dinâmicas $\tau$.
% Derivada das equações da dinâmica do movimento a partir da seção 6.7 do
% Craig.
%
%% Calling Syntax
% gravity=gravity(theta)
%
%% I/O Variables
% |IN Double Array| *theta*: _Joint angles_  [ $\theta_1$ $\theta_2$ $\theta_3$] [degrees degrees degrees]
%
% |OU Double List| *gravity*: $G(\Theta)$ 3x1 Gravity matrix
%
%% Example
% theta = [-30 30 10];
%
% gravity=gravity(theta)
%
%% Hypothesis
% RRR planar robot.
%
%% Limitations
% A "Forma do usuário" é específica para o exercício de simulação e não tem
% validade para qualquer configuração de robô.
% Considera o robô planar com os valores de comprimentos dos ligamentos = {0.5, 0.3, 0}
% e Massas = {4.6, 2.3, 1} fixos.
%
%% Version Control
%
% 1.0; Grupo 04; 2025/31/05 ; First issue.
%
%% Group Members
% * Guilherme Fortunato Miranda
%
%   13683786
%
% * João Pedro Dionizio Calazans
%
%   13673086
%    
%% Function
function gravity=gravity(theta)

%% Validity
% Not apply

%% Main Calculations
theta = theta*pi/180;
g = 9.8;
L = [0.5,0.3,0];
M = [4.6,2.3,1];
 
%% Output Data
    gravity = [-g*(2*L(1)*M(1)*cos(theta(1)) + L(1)*M(2)*cos(theta(1)) + L(1)*M(3)*cos(theta(1)) + L(3)*M(3)*cos(theta(1) + theta(2) + theta(3)) + 2*L(2)*M(2)*cos(theta(1) + theta(2)) + L(2)*M(3)*cos(theta(1) + theta(2))), - 2*g*L(2)*M(2)*cos(theta(1) + theta(2)) - g*L(2)*M(3)*cos(theta(1) + theta(2)) - g*L(3)*M(3)*cos(theta(1) + theta(2) + theta(3)), -g*L(3)*M(3)*cos(theta(1) + theta(2) + theta(3))];
            
end
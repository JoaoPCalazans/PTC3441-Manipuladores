%% INV_M
% Calcula a matriz $M^{-1}(\Theta)$ para determinação do vetor de forças
% dinâmicas $\tau$.
% Derivada das equações da dinâmica do movimento a partir da seção 6.7 do
% Craig.
%
%% Calling Syntax
% inv_m=inv_m(theta)
%
%% I/O Variables
% |IN Double Array| *theta*: _Joint angles_  [ $\theta_1$ $\theta_2$ $\theta_3$] [degrees degrees degrees]
%
% |OU Double List| *inv_m*: $M^{-1}(\Theta)$ 3x3 Inverse inertia matrix
%
%% Example
% theta = [-30 30 10];
%
% inv_m=inv_m(theta)
%
%% Hypothesis
% RRR planar robot.
%
%% Limitations
% A "Forma do usuário" é específica para o exercício de simulação e não tem
% validade para qualquer configuração de robô.
% Considera o robô planar com os valores de comprimentos dos ligamentos = {0.5, 0.3, 0}
% e Massas = {4.6, 2.3, 1} fixos.
%
%% Version Control
%
% 1.0; Grupo 04; 2025/31/05 ; First issue.
%
%% Group Members
% * Guilherme Fortunato Miranda
%
%   13683786
%
% * João Pedro Dionizio Calazans
%
%   13673086
%    
%% Function
function inv_m=inv_m(theta)

%% Validity
% Not apply

%% Main Calculations
theta = theta*pi/180;
L = [0.5,0.3,0];
M = [4.6,2.3,1];
Mega_M = zeros(3,3);
Mega_M(1,:) = [4*L(1)^2*M(1) + L(1)^2*M(2) + L(1)^2*M(3) + 4*L(2)^2*M(2) + L(2)^2*M(3) + L(3)^2*M(3) + 2*L(1)*L(3)*M(3)*cos(theta(2) + theta(3)) + 4*L(1)*L(2)*M(2)*cos(theta(2)) + 2*L(1)*L(2)*M(3)*cos(theta(2)) + 2*L(2)*L(3)*M(3)*cos(theta(3)) + 1/10, 4*L(2)^2*M(2) + L(2)^2*M(3) + L(3)^2*M(3) + L(1)*L(3)*M(3)*cos(theta(2) + theta(3)) + 2*L(1)*L(2)*M(2)*cos(theta(2)) + L(1)*L(2)*M(3)*cos(theta(2)) + 2*L(2)*L(3)*M(3)*cos(theta(3)) + 1/10, L(3)^2*M(3) + L(1)*L(3)*M(3)*cos(theta(2) + theta(3)) + L(2)*L(3)*M(3)*cos(theta(3)) + 1/10];
Mega_M(2,:) = [                                    4*L(2)^2*M(2) + L(2)^2*M(3) + L(3)^2*M(3) + L(1)*L(3)*M(3)*cos(theta(2) + theta(3)) + 2*L(1)*L(2)*M(2)*cos(theta(2)) + L(1)*L(2)*M(3)*cos(theta(2)) + 2*L(2)*L(3)*M(3)*cos(theta(3)) + 1/10,                                                                 4*L(2)^2*M(2) + L(2)^2*M(3) + L(3)^2*M(3) + 2*L(2)*L(3)*M(3)*cos(theta(3)) + 1/10,                            L(3)*M(3)*(L(3) + L(2)*cos(theta(3))) + 1/10];
Mega_M(3,:) = [                                                                                                    L(3)^2*M(3) + L(1)*L(3)*M(3)*cos(theta(2) + theta(3)) + L(2)*L(3)*M(3)*cos(theta(3)) + 1/10,                                                                                         M(3)*L(3)^2 + L(2)*M(3)*cos(theta(3))*L(3) + 1/10,                                            M(3)*L(3)^2 + 1/10];

%% Output Data
    inv_m = inv(Mega_M);
            
end
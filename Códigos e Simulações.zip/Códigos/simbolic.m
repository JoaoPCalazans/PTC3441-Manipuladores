syms q1 q2 q3 dq1 dq2 dq3 l1 l2;
theta = [q1,q2,q3];
L = [l1, l2];
jac_old= sym(zeros(6,3));
jac_old(1,1:3) = [L(1)*sin(sum(theta(2:3)))+L(2)*sin(theta(3)) L(2)*sin(theta(3)) 0];
jac_old(2,1:3) = [L(1)*cos(sum(theta(2:3)))+L(2)*cos(theta(3)) L(2)*cos(theta(3)) 0];
jac_old(6,1:3) = [1 1 1];

R01= [cos(q1),-sin(q1),0;sin(q1),cos(q1),0;0,0,1];
R12= [cos(q2),-sin(q2),0;sin(q2),cos(q2),0;0,0,1];
R23= [cos(q1),-sin(q3),0;sin(q3),cos(q3),0;0,0,1];
R03= R01*R12*R23;

new_jac = [R03,zeros(3,3);zeros(3,3),R03]*jac_old;
disp(new_jac);


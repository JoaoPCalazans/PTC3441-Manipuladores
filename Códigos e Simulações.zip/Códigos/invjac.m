%% INVJAC   
% Para o exercício 4, calcula a matriz $J^{-1}(\Theta)$ para determinação
% do vetor de velocidades relativas das juntas $\dot{\Theta}$ a partir de
% $^k\dot{X}=^kJ\dot{\Theta}$, em que $^kJ$ é a matriz jacobiana e $^kX$ é
% o vetor de velocidades cartesianas comandadas (de translação e de
% rotação).
%
%% Calling Syntax
% [invjac]=invjac(theta,L)
%
%% I/O Variables
% |IN Double Array| *theta*: _Joint angles_  [ $\theta_1$ $\theta_2$ $\theta_3$] [degrees degrees degrees]
%
% |IN Double Array| *L*: _Ligaments length_  [ $L_1$ $L_2$] [meters meters]
%
% |OU Double Matrix| *invjac*: _sistem {3} inverse jacobian_ 6x3 Matrix
%
%% Example
%  theta = [10 20 30]
%
%  L = [0.5 0.3]
%
%  [invjac]=invjac(theta,L)
%
%% Hypothesis
% RRR planar robot.
%
%% Limitations
% A "Forma do usuário" é específica para o exercício de simulação e não tem
% validade para qualquer configuração de robô.
%
%% Version Control
%
% 1.0; Grupo 04; 2025/31/05 ; First issue.
%
%% Group Members
% * Guilherme Fortunato Miranda
%
%   13683786
%
% * João Pedro Dionizio Calazans
%
%   13673086
%    
%% Function
function [invjac]=invjac(theta,L)

%% Validity
% Not apply

%% Main Calculations
    jac = zeros(3,3);
    
%% Output Data
    %     referenciando o J(3) utilizado no exercicio 3
    jac(1,1:3) = [L(1)*sind(sum(theta(2:3)))+L(2)*sind(theta(3)) L(2)*sind(theta(3)) 0];
    jac(2,1:3) = [L(1)*cosd(sum(theta(2:3)))+L(2)*cosd(theta(3)) L(2)*cosd(theta(3)) 0];
    jac(3,1:3) = [1 1 1];
    invjac = inv(jac);

end